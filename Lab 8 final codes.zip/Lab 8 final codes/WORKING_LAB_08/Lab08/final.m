pixels = colour_object_detection(1)
real_coo = pixel_coo_to_real(pixels)
x = real_coo(1)/10
y = real_coo(2)/10
PickandPlace(-31.6,16.4,-3,10,14,-3)

%PickandPlace(-314.6,164.7,100,-100, 100, 100)
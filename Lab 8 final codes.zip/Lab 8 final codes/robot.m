function robot()
%% Create all objects to be used in this file
    % Make Pipeline object to manage streaming
    pipe = realsense.pipeline();
    % Make Colorizer object to prettify depth output
    colorizer = realsense.colorizer();
    % Create a config object to specify configuration of pipeline
    cfg = realsense.config();

    
    %% Set configuration and start streaming with configuration
    % Stream options are in stream.m
    streamType = realsense.stream('depth');
    % Format options are in format.m
    formatType = realsense.format('Distance');
    % Enable default depth
    cfg.enable_stream(streamType,formatType);
    % Enable color stream
    streamType = realsense.stream('color');
    formatType = realsense.format('rgb8');
    cfg.enable_stream(streamType,formatType);
    
    % Start streaming on an arbitrary camera with chosen settings
    profile = pipe.start();

    %% Acquire and Set device parameters 
    % Get streaming device's name
    dev = profile.get_device();    
    name = dev.get_info(realsense.camera_info.name);

    % Access Depth Sensor
    depth_sensor = dev.first('depth_sensor');

    % Access RGB Sensor
    rgb_sensor = dev.first('roi_sensor');
    
    % Find the mapping from 1 depth unit to meters, i.e. 1 depth unit =
    % depth_scaling meters.
    depth_scaling = depth_sensor.get_depth_scale();

    % Set the control parameters for the depth sensor
    % See the option.m file for different settable options that are visible
    % to you in the viewer. 
    optionType = realsense.option('visual_preset');
    % Set parameters to the midrange preset. See for options:
    % https://intelrealsense.github.io/librealsense/doxygen/rs__option_8h.html#a07402b9eb861d1defe57dbab8befa3ad
    depth_sensor.set_option(optionType,9);

    % Set autoexposure for RGB sensor
    optionType = realsense.option('enable_auto_exposure');
    rgb_sensor.set_option(optionType,1);
    optionType = realsense.option('enable_auto_white_balance');
    rgb_sensor.set_option(optionType,1);    
    
    %% Align the color frame to the depth frame and then get the frames
    % Get frames. We discard the first couple to allow
    % the camera time to settle
    for i = 1:5
        fs = pipe.wait_for_frames();
    end
    
    % Alignment
    align_to_depth = realsense.align(realsense.stream.depth);
    fs = align_to_depth.process(fs);

    % Stop streaming
    pipe.stop();

    %% Depth Post-processing
    % Select depth frame
    depth = fs.get_depth_frame();
    width = depth.get_width();
    height = depth.get_height();
    
    % Decimation filter of magnitude 2
%     dec = realsense.decimation_filter(2);
%     depth = dec.process(depth);

    % Spatial Filtering
    % spatial_filter(smooth_alpha, smooth_delta, magnitude, hole_fill)
    spatial = realsense.spatial_filter(.5,20,2,0);
    depth_p = spatial.process(depth);

    % Temporal Filtering
    % temporal_filter(smooth_alpha, smooth_delta, persistence_control)
    temporal = realsense.temporal_filter(.13,20,3);
    depth_p = temporal.process(depth_p);
    
    %% Color Post-processing
    % Select color frame
    color = fs.get_color_frame();    
    
    %% Colorize and display depth frame
    % Colorize depth frame
    depth_color = colorizer.colorize(depth_p);

    % Get actual data and convert into a format imshow can use
    % (Color data arrives as [R, G, B, R, G, B, ...] vector)fs
    data = depth_color.get_data();
    img = permute(reshape(data',[3,depth_color.get_width(),depth_color.get_height()]),[3 2 1]);

    % Display image
    imshow(img);
    title(sprintf("Colorized depth frame from %s", name));

    %% Display RGB frame
    % Get actual data and convert into a format imshow can use
    % (Color data arrives as [R, G, B, R, G, B, ...] vector)fs
    data2 = color.get_data();
    im = permute(reshape(data2',[3,color.get_width(),color.get_height()]),[3 2 1]);

    % Display image
    figure;
    imshow(im);
    title(sprintf("Color RGB frame from %s", name));

    %% Depth frame without colorizing    
    % Convert depth values to meters
    data3 = depth_scaling * depth_p.get_data();

    %Arrange data in the right image format
    ig = permute(reshape(data3',[width,height]),[2 1]);
    
    % Scale depth values to [0 1] for display
    figure;
    imshow(mat2gray(ig));
    


    BW = imbinarize(im);
    bin_img = BW;
    figure;
    imshowpair(im,BW,'montage');
    title('RGB Image & its binarized version');
    len = size(BW);
    
    BW2 = ~(BW(:,:,1) & BW(:,:,2) & BW(:,:,3));
    BW3 = BW2;
    figure;
    imshow(BW3);
    
    title('Inverted Binarized Image');
    cc8 = bwconncomp(BW3);
    remove_idx = [];
    
    % here we filter out everyother thing except the cubes using 
    % connected components that are too big or too small
    
    for i = 1:length(cc8.PixelIdxList)
        if (length(cc8.PixelIdxList{i}) < 200) || (length(cc8.PixelIdxList{i}) > 2000)
            remove_idx(end + 1) = i;
        end
    end
    
    for i=1:length(remove_idx)
        BW2(cc8.PixelIdxList{remove_idx(i)}) = 0;
    end
    
    
    figure;
    imshowpair(BW3, BW2, 'montage');
    title('Before & After');
    cc8 = bwconncomp(BW2); %function dettects on it own
    
    
    BW4 = BW2;
    object_info = struct;
    object_info.Index_data = cc8.PixelIdxList; % Object Indices
    object_info.rgb_image = im2double(im); % RGB Image
    object_info.depth_info_cm = ig*100; % Depth Info in sm
    
    object_info.red_val = zeros(1,length(object_info.Index_data)); % Avg Red for each obj
    
    object_info.green_val = zeros(1,length(object_info.Index_data)); % Avg Green for each obj
    
    object_info.blue_val = zeros(1,length(object_info.Index_data)); % Avg Blue for each obj
    
    object_info.red_val_max = zeros(1,length(object_info.Index_data)); % Max Red for each obj
    
    object_info.green_val_max = zeros(1,length(object_info.Index_data)); % Max Green for each obj
    
    object_info.blue_val_max = zeros(1,length(object_info.Index_data)); % Max Blue for each obj
    
    
    object_info.top_data = object_info.Index_data; % Indices for top faces of object
    object_info.top_data_width = object_info.Index_data; % x Indices for top faces of object
    object_info.top_data_column = object_info.Index_data; % y Indices for top faces of object
    object_info.no_top_data = object_info.Index_data;
    object_info.center_x = zeros(1, length(object_info.Index_data));
    object_info.center_y = zeros(1, length(object_info.Index_data));
    object_info.red_val_bin = zeros(1,length(object_info.Index_data));
    object_info.green_val_bin = zeros(1,length(object_info.Index_data));
    object_info.blue_val_bin = zeros(1,length(object_info.Index_data));
    
    %top data extraction
    for i = 1:length(object_info.Index_data)
        arr = [];
        for j = 1:length(object_info.Index_data{i}) %removing zero depth pixels
            if object_info.depth_info_cm(object_info.Index_data{i}(j)) ~= 0
                arr(end +1) = object_info.depth_info_cm(object_info.Index_data{i}(j));
            end
        end
        counts = hist(arr, 10);
        % figure;
        % histogram(arr,10);
        %start
        th = min(arr) + (otsuthresh(counts)*(max(arr) - min(arr)));
        r = 0;
        l = 0;
        for j = 1:length(object_info.Index_data{i}) 
            
            if object_info.depth_info_cm(object_info.Index_data{i}(j)) > th
                BW4(object_info.Index_data{i}(j)) = 0;
                object_info.top_data{i}(j-r) = [];
                r = r + 1;
            else
                object_info.no_top_data{i}(j-l) = [];
                l = l + 1;
            end
        end
    end
    
    for i = 1:length(object_info.top_data)
        object_info.top_data_column{i} = floor(object_info.top_data{i} ./ len(1)) + 1;
        object_info.top_data_width{i} = mod(object_info.top_data{i}, len(1));
        object_info.center_x(i) = floor(mean(object_info.top_data_width{i}));
        object_info.center_y(i) = floor(mean(object_info.top_data_column{i}));
        BW4(object_info.center_x(i), object_info.center_y(i)) = 0;
    end
    
    
    figure;
    imshowpair(BW2, BW4, 'montage');
    title('Face top detection');
    avg_th = 0.2;
    max_th = 0.3;
    for k = 1:length(object_info.top_data_width)
        val_r = 0;
        val_g = 0;
        val_b = 0;
        max_r = -inf;
        max_g = -inf;
        max_b = -inf;
        for i = 1:length(object_info.top_data_width{k})
                if (object_info.rgb_image(object_info.top_data_width{k}(i),object_info.top_data_column{k}(i),1) > max_r)
                    max_r = object_info.rgb_image(object_info.top_data_width{k}(i),object_info.top_data_column{k}(i),1);
                end
                if (object_info.rgb_image(object_info.top_data_width{k}(i),object_info.top_data_column{k}(i),2) > max_g)
                    max_g = object_info.rgb_image(object_info.top_data_width{k}(i),object_info.top_data_column{k}(i),2);
                end
                if (object_info.rgb_image(object_info.top_data_width{k}(i),object_info.top_data_column{k}(i),3) > max_b)
                    max_b = object_info.rgb_image(object_info.top_data_width{k}(i),object_info.top_data_column{k}(i),3);
                end
                val_r = val_r + object_info.rgb_image(object_info.top_data_width{k}(i),object_info.top_data_column{k}(i),1);
                val_g = val_g + object_info.rgb_image(object_info.top_data_width{k}(i),object_info.top_data_column{k}(i),2);
                val_b = val_b + object_info.rgb_image(object_info.top_data_width{k}(i),object_info.top_data_column{k}(i),3);
        end
        object_info.red_val(k) = val_r / length(object_info.top_data_width{k});
        object_info.green_val(k) = val_g / length(object_info.top_data_width{k});
        object_info.blue_val(k)= val_b / length(object_info.top_data_width{k});
        object_info.red_val_max(k) = max_r;
        object_info.green_val_max(k) = max_g;
        object_info.blue_val_max(k) = max_b;
        if object_info.red_val(k) >= 0.2 && object_info.red_val_max(k) > 0.30
            object_info.red_val_bin(k) = 1;
        end
        if object_info.green_val(k) >= 0.2 && object_info.green_val_max(k) > 0.30
            object_info.green_val_bin(k) = 1;
        end
        if object_info.blue_val(k) >= 0.2 && object_info.blue_val_max(k) > 0.30
            object_info.blue_val_bin(k) = 1;
        end
    end
    object_info
    
    pick_up_x = object_info.center_x(1)
    pick_up_y = object_info.center_y(1)
    input_to_lab7 = [pick_up_x,pick_up_y]


    
   
end
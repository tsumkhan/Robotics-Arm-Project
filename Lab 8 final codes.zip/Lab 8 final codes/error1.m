function [corr_theta] = error1(theta)
corr_theta = mod(theta+pi,2*pi) - pi;
end
